
"""
graph TD
        A[1. 데이터셋 스캔] --> B[2. 4코어 병렬 워커 가동]
        B --> C["3. 비디오 1차 로드 (디스크 읽기/해독)"]
        C --> D[4. 화질 축소 및 격자 분석]
        D --> E["5. Fused FFT 주기성 맵 계산 (12~48 BPM 필터)"]
        E --> F["6. 3x3 체인 확장 격자 선정 (corr >= 0.9)"]
        F --> G[7. 선정된 격자 신호 앙상블 평균]
        G --> H[8. FFT 최고 피크 기반 est_bpm 추정]
        H --> I[9. 정답 로드 및 피크 검출 gt_bpm 계산]
        I --> J["10. 비디오 2차 로드 (디스크 재디코딩)"]
        J --> K[11. 시각화 PNG 및 NPZ 저장]
        K --> L[12. 최종 CSV 통계 저장 및 리포트]
"""

import cv2
import numpy as np
import os
import glob
import re
import sys
import multiprocessing
import csv
from scipy.fft import fft, fftfreq
from scipy.signal import butter, filtfilt, resample, find_peaks
import h5py
import matplotlib
matplotlib.use('Agg')
from matplotlib.figure import Figure
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
import matplotlib.patches as patches
from tqdm import tqdm
from scipy.signal import detrend
# from cache_save_SVD_PCA import get_or_create_cached_signals



# ==========================================

# 1. Path & Configuration
# ==========================================
DATASET_DIR = r"C:\Users\USER\VScode\neonate\dataset\RE_baby"
SAVE_DIR = r"D:\neonate\test_scale_0.2_corr_0.8"
VISUAL_DIR = r"D:\neonate\test_scale_0.2_corr_0.8"
CSV_PATH = r"D:\neonate\test_scale_0.2_corr_0.8\respiration_bpm_results_get_bpm_by_peaks_0.2_0.8.csv"

GRID_SIZE = (32, 18)
BREATHING_BAND = (0.2, 0.8)  # Extended to 1.2 Hz (12~60 BPM) to cover standard breathing range
SCALE_FACTOR = 0.2
MAX_ALLOWED_VARIATION = 5.0
TOP_K_CELLS = 3  # Top cells
NUM_WORKERS = 4  # 🌟 8코어 16스레드 CPU 환경에 최적화된 멀티프로세스 개수

# ==========================================
# 2. Helper Functions
# ==========================================

# 2.1 video(mp4)와 gt(hdf5) - 짝 맞추기 함수(pairs)
def get_all_video_gt_pairs(dataset_dir):
    pairs = []
    for root, dirs, files in os.walk(dataset_dir):
        for f in files:
            if f.endswith('.mp4'):
                v = os.path.join(root, f)
                folder = os.path.dirname(v)
                filename = os.path.splitext(f)[0]
                gt_path = os.path.join(folder, "out", f"{filename}.hdf5")
                if os.path.exists(gt_path):
                    pairs.append((os.path.normpath(v), os.path.normpath(gt_path)))
    pairs = sorted(pairs, key=lambda x: x[0])
    return pairs

# 2.2 bandpass 함수 
def bandpass(sig, fs, low, high):
    nyq = 0.5 * fs
    b, a = butter(3, [low/nyq, high/nyq], btype='band')
    return filtfilt(b, a, sig)

# 2.3 est_bpm 연산하는 함수
def calculate_bpm_from_signal(sig, fs, band=BREATHING_BAND):
    # 📌 기존 코드
    # sig_detrend = sig - np.mean(sig)
    # N = len(sig_detrend)

    # ⭐ 변경사항 ⭐
    sig = sig - np.mean(sig) # 평균 뺴서, 신호 정렬
    N = len(sig)

    # zero-padding -------------------> ⭐ 변경사항 ⭐
    # Nfft = max(4096, 2 ** int(np.ceil(np.log2(N))))
    # yf = np.abs(fft(sig, n=Nfft))

    # 📌 기본 코드 -> 주파수 분석을 위해서 FFT 수행
    yf = np.abs(fft(sig))
    freqs = fftfreq(N, 1/fs)

    # 호흡 대역 필터링
    mask = (freqs >= band[0]) & (freqs <= band[1])
    if np.any(mask):
        # argmax니까, 최고 피크 검출
        peak_idx = np.argmax(yf[mask])
        peak_freq = freqs[mask][peak_idx]
        return peak_freq * 60.0
    else:
        return np.nan
        # return 0.0

# 2.4 gt_bpm 연산하는 함수
def get_bpm_by_peaks(sig, fs):
    sig_detrend = detrend(sig) # 봉우리 검출기가 정상적으로 높낮이를 판별할 수 있도록 돕는 것 - 선형적 흐름 제거 -> 신호 평평
    # sig_filt = bandpass(sig_detrend, fs, BREATHING_BAND[0], BREATHING_BAND[1])
    min_dist = int(fs / 1.5)
    # 신호에서 들숨 최고점 좌표를 찾아냄
    # 전체 신호 표준편차의 30% 이상 솟구쳐 있어야 진짜 호흡으로 인정 = 미세하고 자잘한 떨림 노이즈 배제
    peaks, _ = find_peaks(sig_detrend, distance=min_dist, prominence=np.std(sig_detrend) * 0.3) 
    if len(peaks) > 1:
        intervals = np.diff(peaks) / fs
        # 구한 호흡 주기 시간에서 중앙값을 최종 호흡 주기로 선정함.
        # 평균값이 아닌 중앙값으로 선택한 이유 : 이상치에 대한 수학적 강인성 
        median_interval = np.median(intervals)
        return 60.0 / median_interval
    else:
        return np.nan
        # return calculate_bpm_from_signal(sig_detrend, fs)


def process_video_to_signals(video_path, grid_size=GRID_SIZE, scale_factor=SCALE_FACTOR):
    cap = cv2.VideoCapture(video_path)
    fps = cap.get(cv2.CAP_PROP_FPS)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
    # 상단 10% crop
    y_start = int(height * 0.1)
    
    color_signals_list = []
    flow_signals_list = []
    frames_cache = []  # 🌟 RAM Cache 추가
    
    ret, first_frame = cap.read()
    if not ret:
        cap.release()
        raise ValueError("Could not read first frame of video.")
        
    frames_cache.append(first_frame)  # 🌟 1번째 프레임 캐싱
    
    cropped_first = first_frame[y_start:, :] # 상단 10% crop된 상태에서 grid 가로/세로 나눔
    # resize 이미지의 모든 개별 픽셀을 대상으로 motion vector - 픽셀 레벨
    # (sw, sh 해상도)
    sh = int(cropped_first.shape[0] * scale_factor)
    sw = int(cropped_first.shape[1] * scale_factor)
    grid_w = sw // grid_size[0]
    grid_h = sh // grid_size[1]
    H_target = grid_size[1] * grid_h
    W_target = grid_size[0] * grid_w
    
    # 1. first frame 처리
    frame_resized = cv2.resize(cropped_first, (sw, sh))
    frame_gray = frame_resized.mean(axis=2)  # BGR mean first
    frame_cropped = frame_gray[:H_target, :W_target]
    reshaped = frame_cropped.reshape(grid_size[1], grid_h, grid_size[0], grid_w)
    color_signals_list.append(reshaped.mean(axis=(1, 3)))
    
    # 초기화 - optical flow는 앞선 프레임이 없으면 optical flow 계산 없어서
    # optical flow 처리하기 위해서, grayscale 변환해서 구동됨
    prev_gray = cv2.cvtColor(cropped_first, cv2.COLOR_BGR2GRAY)
    prev_resized = cv2.resize(prev_gray, (sw, sh))
    
    frame_idx = 1
    
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
            
        frames_cache.append(frame)  # 🌟 프레임 캐싱
        cropped_frame = frame[y_start:, :]
        
        # Color extraction
        frame_resized_color = cv2.resize(cropped_frame, (sw, sh))
        frame_gray_color = frame_resized_color.mean(axis=2)  # BGR mean first
        frame_cropped_color = frame_gray_color[:H_target, :W_target]
        reshaped_color = frame_cropped_color.reshape(grid_size[1], grid_h, grid_size[0], grid_w)
        color_signals_list.append(reshaped_color.mean(axis=(1, 3)))
        
        # Grayscale resize for flow
        curr_gray = cv2.cvtColor(cropped_frame, cv2.COLOR_BGR2GRAY)
        curr_resized = cv2.resize(curr_gray, (sw, sh))
        
        # Calculate dense optical flow (Farneback - Low CPU setup)
        flow = cv2.calcOpticalFlowFarneback(
            prev_resized, curr_resized, None, 
            pyr_scale=0.5, levels=2, winsize=13, 
            iterations=2, poly_n=5, poly_sigma=1.1, flags=0
        )
        flow_v = flow[..., 1]  # vertical motion velocity
        
        # Grid average flow
        # 🌟 픽셀 레벨의 세로 속도 맵을 격자별 평균으로 압축
        flow_cropped = flow_v[:H_target, :W_target]
        # grid cell에 맞게 변환해서 담음
        reshaped_flow = flow_cropped.reshape(grid_size[1], grid_h, grid_size[0], grid_w)
        flow_signals_list.append(reshaped_flow.mean(axis=(1, 3))) # 평균 취함
        
        prev_resized = curr_resized
        frame_idx += 1
        
    cap.release()
    
    color_signals = np.transpose(np.array(color_signals_list), (1, 2, 0))
    flow_signals = np.transpose(np.array(flow_signals_list), (1, 2, 0))
    
    return color_signals, flow_signals, fps, width, height, y_start, grid_w, grid_h, frames_cache

# 탐색을 통해 찾아낸 최적의 호흡 영역을 원본 비디오 화질(고해상도) 크기로 역추적해서 crop하여 저장용 데이터로 추출해주는 함수
def extract_roi_frames(frames_cache, top_cells, grid_size, scale_factor, y_start, grid_w, grid_h, target_size=(200, 200)):
    if len(frames_cache) == 0:
        return [np.zeros((0, target_size[1], target_size[0], 3), dtype=np.uint8) for _ in range(len(top_cells))]
        
    first_frame = frames_cache[0]
    height, width = first_frame.shape[:2]
    
    roi_frames_list = [[] for _ in range(len(top_cells))]
    
    for frame in frames_cache:
        for i, (gy, gx, _) in enumerate(top_cells):
            x_start_resized = gx * grid_w
            x_end_resized = (gx + 1) * grid_w
            y_start_resized = gy * grid_h
            y_end_resized = (gy + 1) * grid_h
            
            x_start_crop = int(x_start_resized / scale_factor)
            x_end_crop = int(x_end_resized / scale_factor)
            y_start_crop = int(y_start_resized / scale_factor)
            y_end_crop = int(y_end_resized / scale_factor)
            
            orig_x1 = max(0, x_start_crop)
            orig_x2 = min(width, x_end_crop)
            orig_y1 = max(0, y_start_crop + y_start)
            orig_y2 = min(height, y_end_crop + y_start)
            
            roi_crop = frame[orig_y1:orig_y2, orig_x1:orig_x2]
            
            if roi_crop.size == 0:
                roi_resized = np.zeros((target_size[1], target_size[0], 3), dtype=np.uint8)
            else:
                roi_resized = cv2.resize(roi_crop, target_size)
                
            roi_frames_list[i].append(roi_resized)
            
    roi_arrays = [np.array(frames, dtype=np.uint8) for frames in roi_frames_list]
    return roi_arrays

# 원본 이미지에 overlay해서 나타남.
def save_overlay_visualization(first_frame, top_cells, filtered_signals, respiration_resampled, final_score_map, grid_size, scale_factor, y_start, grid_w, grid_h, save_path):
    cropped_frame = first_frame[y_start:, :]
    cropped_rgb = cv2.cvtColor(cropped_frame, cv2.COLOR_BGR2RGB)
    
    fig = Figure(figsize=(16, 7))
    canvas = FigureCanvas(fig)
    axes = fig.subplots(1, 2)
    
    heatmap_resized = cv2.resize(final_score_map, (cropped_frame.shape[1], cropped_frame.shape[0]))
    heatmap_norm = cv2.normalize(heatmap_resized, None, 0, 255, cv2.NORM_MINMAX)
    heatmap_color = cv2.applyColorMap(np.uint8(heatmap_norm), cv2.COLORMAP_JET)
    heatmap_color_rgb = cv2.cvtColor(heatmap_color, cv2.COLOR_BGR2RGB)
    
    overlay = cv2.addWeighted(cropped_rgb, 0.6, heatmap_color_rgb, 0.4, 0)
    axes[0].imshow(overlay)
    
    colors = ['red', 'green', 'blue', 'orange']
    
    for i, (gy, gx, score) in enumerate(top_cells):
        x_start_resized = gx * grid_w
        x_end_resized = (gx + 1) * grid_w
        y_start_resized = gy * grid_h
        y_end_resized = (gy + 1) * grid_h
        
        x1 = int(x_start_resized / scale_factor)
        x2 = int(x_end_resized / scale_factor)
        y1 = int(y_start_resized / scale_factor)
        y2 = int(y_end_resized / scale_factor)
        
        rect = patches.Rectangle((x1, y1), x2 - x1, y2 - y1, fill=False, edgecolor=colors[i % len(colors)], linewidth=2)
        axes[0].add_patch(rect)
        axes[0].text(x1, y1 - 10, f"Rank {i+1}", color=colors[i % len(colors)], fontsize=10, weight='bold', bbox=dict(facecolor='white', alpha=0.7, edgecolor='none', pad=1))
        
    axes[0].set_title("Top Cell Bounding Boxes on Fused Heatmap")
    axes[0].axis('off')
    
    # Plot GT
    gt_norm = (respiration_resampled - np.mean(respiration_resampled)) / (np.std(respiration_resampled) + 1e-8)
    axes[1].plot(gt_norm, label="Ground Truth (Resampled)", color='black', linewidth=2.0, linestyle='--')
    
    for i, sig in enumerate(filtered_signals):
        sig_norm = (sig - np.mean(sig)) / (np.std(sig) + 1e-8)
        axes[1].plot(sig_norm, label=f"Rank {i+1} (Grid {top_cells[i][0]},{top_cells[i][1]})", color=colors[i % len(colors)], linewidth=1.5)
        
    axes[1].set_title("Normalized Respiration Signals Comparison")
    axes[1].set_xlabel("Frames")
    axes[1].set_ylabel("Normalized Amplitude")
    axes[1].legend()
    axes[1].grid(True, linestyle=':', alpha=0.6)
    
    fig.suptitle(f"Subject Visual Analysis (PP + Optical Flow) - {os.path.basename(save_path)}", fontsize=14, weight='bold')
    fig.tight_layout()
    fig.savefig(save_path, dpi=150)

# ==========================================
# 3. Worker Function for Parallel Processing
# ==========================================
def process_single_video_worker(args):
    video_path, gt_path, idx, total_count, scale_factor = args
    subject_folder = os.path.basename(os.path.dirname(video_path))
    video_name = os.path.splitext(os.path.basename(video_path))[0]
    
    # Initialize failure result with a sweep dictionary
    fail_result = {
        'status': 'false',
        'sample_id': idx + 1,
        'video': video_name + '.mp4',
        'subject': subject_folder,
        'roi': 'N/A',
        'gt_bpm': 0.0,
        'k_results': {k: {'est_bpm': 0.0, 'accuracy': 0.0, 'snr': np.nan} for k in [1, 2, 3, 4, 5]}
    }
    
    try:
        # Extract color and optical flow signals
        color_signals, flow_signals, fps, width, height, y_start, grid_w, grid_h, frames_cache = process_video_to_signals(video_path, scale_factor=scale_factor)
        total_frames = color_signals.shape[2]
        
        # Color difference & z-score
        color_signals_diff = np.diff(color_signals, axis=2)
        mean_c = np.mean(color_signals_diff, axis=2, keepdims=True)
        std_c = np.std(color_signals_diff, axis=2, keepdims=True)
        color_norm = (color_signals_diff - mean_c) / (std_c + 1e-8)
        
        # Flow z-score
        mean_f = np.mean(flow_signals, axis=2, keepdims=True)
        std_f = np.std(flow_signals, axis=2, keepdims=True)
        flow_norm = (flow_signals - mean_f) / (std_f + 1e-8)
        
        # Fused FFT Periodicity Map
        periodicity_map = np.zeros((GRID_SIZE[1], GRID_SIZE[0]))
        freqs = fftfreq(total_frames - 1, 1/fps)
        mask = (freqs >= BREATHING_BAND[0]) & (freqs <= BREATHING_BAND[1])
        
        for gy in range(GRID_SIZE[1]):
            for gx in range(GRID_SIZE[0]):
                # 1. Color Signal FFT
                sig_c = color_norm[gy, gx]
                sig_c = sig_c - np.mean(sig_c)
                yf_c = np.abs(fft(sig_c))

                # Calculate Color soft variance penalty
                raw_diff_c = np.diff(color_signals[gy, gx])
                max_var_c = np.max(np.abs(raw_diff_c))
                penalty_c = np.exp(-0.2 * max(0.0, max_var_c - MAX_ALLOWED_VARIATION))
                
                # 2. Flow Signal FFT
                sig_f = flow_norm[gy, gx]
                sig_f = sig_f - np.mean(sig_f)
                yf_f = np.abs(fft(sig_f))

                # Calculate Flow soft variance penalty
                raw_diff_f = np.diff(flow_signals[gy, gx])
                max_var_f = np.max(np.abs(raw_diff_f))
                penalty_f = np.exp(-0.04 * max(0.0, max_var_f - MAX_ALLOWED_VARIATION * 5.0))
                
                # 3. Fused FFT
                yf_fused = yf_c * yf_f
                
                if np.any(mask):
                    dominant = np.max(yf_fused[mask])
                    total = np.sum(yf_fused)
                    periodicity_map[gy, gx] = dominant / (total + 1e-8)
        
        def get_correlation(sig1, sig2):
            s1, s2 = sig1 - np.mean(sig1), sig2 - np.mean(sig2)
            denom = np.sqrt(np.sum(s1**2) * np.sum(s2**2))
            return np.sum(s1 * s2) / denom if denom > 1e-8 else 0.0
        
        flat_idx = np.argsort(periodicity_map.flatten())[::-1]
        top_cells = []

        # 1. 전역 점수 1위 Top-1 셀 확정
        for i_idx in flat_idx:
            gy, gx = np.unravel_index(i_idx, periodicity_map.shape)
            score = periodicity_map[gy, gx]
            if score > 0:
                top_cells.append((gy, gx, score))
                break

        # 2. Top-1 중심 3x3 인접 동조 셀(corr >= 0.9) 연쇄 확장 (최대 K=5까지 수확)
        if len(top_cells) > 0:
            curr_gy, curr_gx, _ = top_cells[0]
            visited = {(curr_gy, curr_gx)}
            
            while len(top_cells) < TOP_K_CELLS:
                ref_sig = flow_norm[curr_gy, curr_gx]
                best_candidate = None
                best_candidate_corr = -1.0
                
                for dy in [-1, 0, 1]:
                    for dx in [-1, 0, 1]:
                        if dy == 0 and dx == 0:
                            continue
                        ny, nx = curr_gy + dy, curr_gx + dx
                        
                        if 0 <= ny < GRID_SIZE[1] and 0 <= nx < GRID_SIZE[0]:
                            if (ny, nx) not in visited:
                                tgt_sig = flow_norm[ny, nx]
                                corr = get_correlation(ref_sig, tgt_sig)
                                if corr >= 0.8 and corr > best_candidate_corr:
                                    best_candidate_corr = corr
                                    best_candidate = (ny, nx, periodicity_map[ny, nx])
                                    
                if best_candidate is not None:
                    top_cells.append(best_candidate)
                    visited.add((best_candidate[0], best_candidate[1]))
                    curr_gy, curr_gx = best_candidate[0], best_candidate[1]
                else:
                    break

        if len(top_cells) == 0:
            print(f"[{idx+1}/{total_count}] Failed: No valid respiratory cells found for {subject_folder}/{video_name}.mp4")
            return fail_result
            
        best_gy, best_gx, best_score = top_cells[0]
        
        # Load GT labels, calculate dynamic sampling rate and gt_bpm
        with h5py.File(gt_path, 'r') as f:
            respiration = f['respiration'][:]
        respiration_resampled = resample(respiration, total_frames)
        
        N_gt = len(respiration)
        duration = total_frames / fps
        fs_gt = N_gt / duration
        gt_bpm = get_bpm_by_peaks(respiration, fs_gt)
        
        if np.isnan(gt_bpm):
            print(f"[{idx+1}/{total_count}] Failed: Invalid GT respiration signal (no peaks) for {subject_folder}/{video_name}.mp4")
            return fail_result
            
        # Calculate results for each K in [1, 2, 3, 4, 5]
        k_results = {}
        for k in [1, 2, 3, 4, 5]:
            top_cells_k = top_cells[:k]
            ensemble_signals = [flow_norm[gy, gx] for gy, gx, _ in top_cells_k] 
            best_flow_sig = np.mean(ensemble_signals, axis=0)
            best_filtered_sig = bandpass(best_flow_sig, fps, BREATHING_BAND[0], BREATHING_BAND[1])
            
            # Compute est_bpm
            est_bpm = calculate_bpm_from_signal(best_filtered_sig, fps)
            
            # Accuracy
            if gt_bpm > 0:
                accuracy = (1.0 - abs(est_bpm - gt_bpm) / gt_bpm) * 100.0
            else:
                accuracy = 0.0
                
            # Compute SNR
            yf = np.abs(fft(best_filtered_sig - np.mean(best_filtered_sig)))
            freqs = fftfreq(len(best_filtered_sig), 1/fps)
            mask = (freqs >= BREATHING_BAND[0]) & (freqs <= BREATHING_BAND[1])
            if np.any(mask) and not np.isnan(est_bpm):
                ref_hz = gt_bpm / 60.0
                freqs_mask = freqs[mask]
                yf_mask = yf[mask]
                signal_range = ((freqs_mask >= ref_hz - 0.05) & (freqs_mask <= ref_hz + 0.05)) | \
                               ((freqs_mask >= 2 * ref_hz - 0.05) & (freqs_mask <= 2 * ref_hz + 0.05))
                signal_energy = np.sum(yf_mask[signal_range] ** 2)
                noise_energy = np.sum(yf_mask[~signal_range] ** 2)
                if noise_energy > 1e-8 and signal_energy > 1e-8:
                    snr = 10 * np.log10(signal_energy / noise_energy)
                else:
                    snr = np.nan
            else:
                snr = np.nan
                
            k_results[k] = {
                'est_bpm': round(est_bpm, 2),
                'accuracy': round(accuracy, 2),
                'snr': round(snr, 2) if not np.isnan(snr) else np.nan
            }
            
        print(f"[{idx+1}/{total_count}] Success: {subject_folder}/{video_name}.mp4 (SF: {scale_factor}, Est(K=5): {k_results[5]['est_bpm']:.1f} BPM, GT: {gt_bpm:.1f} BPM, Acc(K=5): {k_results[5]['accuracy']:.1f}%)")
        
        return {
            'status': 'success',
            'sample_id': idx + 1,
            'video': video_name + '.mp4',
            'subject': subject_folder,
            'roi': f"({best_gy},{best_gx})",
            'gt_bpm': round(gt_bpm, 2),
            'k_results': k_results
        }
        
    except Exception as e:
        print(f"[{idx+1}/{total_count}] Error processing {video_path}: {e}")
        import traceback
        traceback.print_exc()
        return fail_result

# ==========================================
# 4. Main Execution Pipeline
# ==========================================
def main():
    print("===== Scanning Dataset for Video-GT Pairs =====")
    pairs = get_all_video_gt_pairs(DATASET_DIR)
    total_count = len(pairs)
    print(f"Found {total_count} valid video-GT pairs in {DATASET_DIR}\n")
    
    if total_count == 0:
        print("[Error] No valid pairs found.")
        return
        
    summary_results = []
    
    # Outer loop for SCALE_FACTOR
    for scale in [0.2]:
        print(f"\n==============================================")
        print(f"Running Experiments for SCALE_FACTOR = {scale}")
        print(f"==============================================")
        
        worker_args = [(pairs[i][0], pairs[i][1], i, total_count, scale) for i in range(total_count)]
        
        results = []
        with multiprocessing.Pool(processes=NUM_WORKERS) as pool:
            results = pool.map(process_single_video_worker, worker_args)
            
        # Sort results by sample_id
        results = sorted(results, key=lambda x: x['sample_id'])
        
        # Collect and compile results for each K in [1, 2, 3, 4, 5]
        for k in [1, 2, 3, 4, 5]:
            compiled_rows = []
            for r in results:
                if r['status'] == 'success':
                    compiled_rows.append({
                        'sample_id': r['sample_id'],
                        'video': r['video'],
                        'subject': r['subject'],
                        'roi': r.get('roi', 'N/A'),
                        'est_bpm': r['k_results'][k]['est_bpm'],
                        'gt_bpm': r['gt_bpm'],
                        'accuracy': r['k_results'][k]['accuracy'],
                        'snr': r['k_results'][k]['snr'],
                        'status': 'success'
                    })
                else:
                    compiled_rows.append({
                        'sample_id': r['sample_id'],
                        'video': r['video'],
                        'subject': r['subject'],
                        'roi': 'N/A',
                        'est_bpm': 0.0,
                        'gt_bpm': 0.0,
                        'accuracy': 0.0,
                        'snr': np.nan,
                        'status': 'false'
                    })
            
            success_rows = [r for r in compiled_rows if r['status'] == 'success']
            success_count = len(success_rows)
            
            if success_count > 0:
                est_bpms = np.array([r['est_bpm'] for r in success_rows])
                gt_bpms = np.array([r['gt_bpm'] for r in success_rows])
                errors = np.abs(est_bpms - gt_bpms)
                
                mae = np.mean(errors)
                rmse = np.sqrt(np.mean(errors**2))
                avg_est_bpm = np.mean(est_bpms)
                avg_gt_bpm = np.mean(gt_bpms)
                avg_accuracy = np.mean([r['accuracy'] for r in success_rows])
                median_accuracy = np.median([r['accuracy'] for r in success_rows])
                
                # Pearson Correlation Coefficient (PCC)
                if len(success_rows) > 1 and np.std(est_bpms) > 0 and np.std(gt_bpms) > 0:
                    pcc = np.corrcoef(est_bpms, gt_bpms)[0, 1]
                else:
                    pcc = 0.0
                    
                # Clinical Success Rates
                success_3bpm = np.mean(errors <= 3.0) * 100.0
                success_5bpm = np.mean(errors <= 5.0) * 100.0
                
                valid_snrs = [r['snr'] for r in success_rows if not np.isnan(r['snr'])]
                avg_snr = np.mean(valid_snrs) if len(valid_snrs) > 0 else 0.0
            else:
                mae = rmse = avg_est_bpm = avg_gt_bpm = avg_accuracy = median_accuracy = pcc = success_3bpm = success_5bpm = avg_snr = 0.0
                
            scale_dir = rf"D:\neonate\experiment_sweep_scale_{scale}_5x5"
            os.makedirs(scale_dir, exist_ok=True)
            csv_path = os.path.join(scale_dir, f"respiration_results_top_{k}.csv")
            
            # Save to CSV
            with open(csv_path, 'w', newline='', encoding='utf-8') as f:
                headers = ['sample_id', 'video', 'subject', 'roi', 'est_bpm', 'gt_bpm', 'accuracy', 'snr', 'status']
                writer = csv.DictWriter(f, fieldnames=headers)
                writer.writeheader()
                for row in compiled_rows:
                    writer.writerow(row)
                    
                writer.writerow({})  # empty spacing row
                writer.writerow({'sample_id': 'Summary Statistics'})
                writer.writerow({'sample_id': 'MAE', 'video': round(mae, 4)})
                writer.writerow({'sample_id': 'RMSE', 'video': round(rmse, 4)})
                writer.writerow({'sample_id': 'Average Est BPM', 'video': round(avg_est_bpm, 2)})
                writer.writerow({'sample_id': 'Average GT BPM', 'video': round(avg_gt_bpm, 2)})
                writer.writerow({'sample_id': 'Average Accuracy', 'video': f"{round(avg_accuracy, 2)}%"})
                writer.writerow({'sample_id': 'Median Accuracy', 'video': f"{round(median_accuracy, 2)}%"})
                writer.writerow({'sample_id': 'PCC', 'video': round(pcc, 4)})
                writer.writerow({'sample_id': 'Success Rate (<3.0 BPM)', 'video': f"{round(success_3bpm, 2)}%"})
                writer.writerow({'sample_id': 'Success Rate (<5.0 BPM)', 'video': f"{round(success_5bpm, 2)}%"})
                writer.writerow({'sample_id': 'Average SNR', 'video': f"{round(avg_snr, 2)} dB"})
            
            print(f" -> K = {k}: MAE = {mae:.4f} | PCC = {pcc:.4f} | Avg SNR = {avg_snr:.2f} dB (Saved: {csv_path})")
            
            summary_results.append({
                'scale': scale,
                'k': k,
                'mae': mae,
                'rmse': rmse,
                'pcc': pcc,
                'avg_snr': avg_snr,
                'success_3bpm': success_3bpm,
                'success_5bpm': success_5bpm
            })
            
    # Print the grand summary table
    print("\n" + "="*95)
    print("GRAND SUMMARY OF EXPERIMENTAL SWEEP")
    print("="*95)
    print(f"{'Scale':<8} | {'K (Cells)':<10} | {'MAE (BPM)':<10} | {'RMSE':<8} | {'PCC':<8} | {'Avg SNR':<12} | {'SR (<3)':<8} | {'SR (<5)':<8}")
    print("-"*95)
    for res in summary_results:
        print(f"{res['scale']:<8} | {res['k']:<10} | {res['mae']:<10.4f} | {res['rmse']:<8.4f} | {res['pcc']:<8.4f} | {res['avg_snr']:<8.2f} dB  | {res['success_3bpm']:<6.1f}% | {res['success_5bpm']:<6.1f}%")
    print("="*95)

if __name__ == "__main__":
    multiprocessing.freeze_support()
    main()
